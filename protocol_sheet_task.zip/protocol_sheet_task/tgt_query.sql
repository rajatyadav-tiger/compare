select 	
tgt.C_CUSTKEY, tgt.C_NAME, tgt.C_ADDRESS, tgt.C_NATIONKEY, tgt.C_PHONE, tgt.C_ACCTBAL,tgt.C_MKTSEGMENT, tgt.C_COMMENT
from target_dataset tgt



